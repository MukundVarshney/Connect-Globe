-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 20, 2018 at 12:04 PM
-- Server version: 5.1.53
-- PHP Version: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `connectglobe`
--

-- --------------------------------------------------------

--
-- Table structure for table `forumadvc`
--

CREATE TABLE IF NOT EXISTS `forumadvc` (
  `RID` int(11) DEFAULT NULL,
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CMT` varchar(4000) DEFAULT NULL,
  `EMAIL` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `forumadvc`
--


-- --------------------------------------------------------

--
-- Table structure for table `forumreg`
--

CREATE TABLE IF NOT EXISTS `forumreg` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(40) NOT NULL,
  `UserPass` varchar(40) NOT NULL,
  `Email` varchar(40) NOT NULL,
  `Mobile` varchar(40) NOT NULL,
  `Address` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `forumreg`
--

INSERT INTO `forumreg` (`Id`, `UserName`, `UserPass`, `Email`, `Mobile`, `Address`) VALUES
(1, 'Ashok', 'admin', 'as@yahoo.com', '9878787878', 'GauGhat');

-- --------------------------------------------------------

--
-- Table structure for table `forumrep`
--

CREATE TABLE IF NOT EXISTS `forumrep` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `COUNTRY` varchar(4000) DEFAULT NULL,
  `STATE` varchar(4000) DEFAULT NULL,
  `DISTRICT` varchar(4000) DEFAULT NULL,
  `POLICE_STATION` varchar(4000) DEFAULT NULL,
  `REPORT` varchar(4000) DEFAULT NULL,
  `STATUS` varchar(4000) DEFAULT NULL,
  `IMAGE` blob,
  `EMAIL` varchar(4000) DEFAULT NULL,
  `POSTEDON` date DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `forumrep`
--

INSERT INTO `forumrep` (`ID`, `COUNTRY`, `STATE`, `DISTRICT`, `POLICE_STATION`, `REPORT`, `STATUS`, `IMAGE`, `EMAIL`, `POSTEDON`) VALUES
(1, 'India', 'Select Please', NULL, NULL, 'I have a big Problem', 'Pending', NULL, 'as@yahoo.com', '2018-01-20'),
(2, 'India', 'UttarPradesh', 'Select Please', NULL, 'jhuhrh k hkeh', 'Pending', NULL, 'as@yahoo.com', '2018-01-20');

-- --------------------------------------------------------

--
-- Table structure for table `forumtadvc`
--

CREATE TABLE IF NOT EXISTS `forumtadvc` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TID` int(11) DEFAULT NULL,
  `CMT` varchar(4000) DEFAULT NULL,
  `EMAIL` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `forumtadvc`
--


-- --------------------------------------------------------

--
-- Table structure for table `forumtpc`
--

CREATE TABLE IF NOT EXISTS `forumtpc` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TOPIC` varchar(4000) DEFAULT NULL,
  `EMAIL` varchar(4000) DEFAULT NULL,
  `CREATEDON` date DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `forumtpc`
--

INSERT INTO `forumtpc` (`ID`, `TOPIC`, `EMAIL`, `CREATEDON`) VALUES
(1, 'Issu', 'as@yahoo.com', '2018-01-20');
